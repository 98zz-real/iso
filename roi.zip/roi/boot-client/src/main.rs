// boot-client — Stufe 2: eigene grafische Oberfläche (Slint, DRM/KMS-Backend)
//
// Die Download-/Verifikationslogik aus Stufe 1 bleibt fachlich unverändert,
// läuft jetzt aber in einem Hintergrund-Thread und meldet Fortschritt über
// einen Channel an die UI zurück (per Timer im UI-Thread gepollt, damit die
// Property-Updates im richtigen Thread passieren).
//
// Bauen/Ausführen setzt eine Umgebung mit KMS-Zugriff voraus (echtes Linux
// mit /dev/dri, entweder auf dem Zielsystem selbst oder in einer VM) — auf
// einem normalen Desktop unter X11/Wayland NICHT einfach `cargo run`,
// sondern auf der Zielkonsole (tty) ohne laufenden Compositor testen.

slint::include_modules!();

use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{Read, Write};
use std::time::Instant;

const SERVER_BASE: &str = "https://boot.chatlh.de";

#[derive(Debug, Deserialize, Clone)]
struct OsSummary {
    id: String,
    name: String,
    version: String,
    #[serde(rename = "type")]
    os_type: String,
}

#[derive(Debug, Deserialize)]
struct OsListResponse {
    os: Vec<OsSummary>,
}

#[derive(Debug, Deserialize)]
struct FileRef {
    #[allow(dead_code)]
    path: String,
    sha256: String,
    url: String,
}

#[derive(Debug, Deserialize)]
struct OsDetails {
    #[serde(rename = "type")]
    os_type: String,
    kernel: Option<FileRef>,
    initrd: Option<FileRef>,
    iso: Option<FileRef>,
    cmdline: Option<String>,
}

/// Nachrichten vom Download-Thread an den UI-Thread.
enum ProgressMsg {
    Status(String),
    Progress { label: String, pct: f32, speed: String, eta: String },
    Done(String),
    Error(String),
}

fn fetch_os_list() -> Result<Vec<OsSummary>, Box<dyn std::error::Error>> {
    let url = format!("{SERVER_BASE}/api/v1/os");
    let resp: OsListResponse = ureq::get(&url).call()?.into_json()?;
    Ok(resp.os)
}

fn fetch_os_details(id: &str) -> Result<OsDetails, Box<dyn std::error::Error>> {
    let url = format!("{SERVER_BASE}/api/v1/os/{id}");
    let details: OsDetails = ureq::get(&url).call()?.into_json()?;
    Ok(details)
}

/// Lädt eine Datei, meldet Fortschritt über `tx`, prüft danach SHA-256.
fn download_and_verify(
    file_ref: &FileRef,
    dest_path: &str,
    label: &str,
    tx: &crossbeam_channel::Sender<ProgressMsg>,
) -> Result<(), Box<dyn std::error::Error>> {
    let url = if file_ref.url.starts_with("http") {
        file_ref.url.clone()
    } else {
        format!("{SERVER_BASE}{}", file_ref.url)
    };

    let resp = ureq::get(&url).call()?;
    let total_len: Option<u64> = resp.header("Content-Length").and_then(|v| v.parse().ok());

    let mut reader = resp.into_reader();
    let mut out_file = File::create(dest_path)?;
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 1024 * 64];
    let mut downloaded: u64 = 0;
    let start = Instant::now();

    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        out_file.write_all(&buf[..n])?;
        hasher.update(&buf[..n]);
        downloaded += n as u64;

        let elapsed = start.elapsed().as_secs_f64().max(0.001);
        let speed_mb_s = (downloaded as f64 / 1_000_000.0) / elapsed;
        let (pct, eta) = match total_len {
            Some(total) if total > 0 => {
                let pct = (downloaded as f64 / total as f64) as f32;
                let remaining = total.saturating_sub(downloaded);
                let eta_s = if speed_mb_s > 0.0 {
                    (remaining as f64 / 1_000_000.0) / speed_mb_s
                } else {
                    0.0
                };
                (pct, format!("{:.0}s", eta_s))
            }
            _ => (0.0, "--".to_string()),
        };

        tx.send(ProgressMsg::Progress {
            label: label.to_string(),
            pct,
            speed: format!("{:.2} MB/s", speed_mb_s),
            eta,
        })
        .ok();
    }

    let computed_hash = format!("{:x}", hasher.finalize());
    if computed_hash != file_ref.sha256 {
        return Err(format!(
            "Hash-Mismatch: erwartet {}, erhalten {}",
            file_ref.sha256, computed_hash
        )
        .into());
    }
    Ok(())
}

/// Läuft im Hintergrund-Thread: Details laden, Dateien laden+prüfen,
/// meldet jeden Schritt über den Channel zurück an die UI.
fn run_install_flow(os_id: String, tx: crossbeam_channel::Sender<ProgressMsg>) {
    tx.send(ProgressMsg::Status(format!("Lade Details für {os_id}..."))).ok();

    let details = match fetch_os_details(&os_id) {
        Ok(d) => d,
        Err(e) => {
            tx.send(ProgressMsg::Error(format!("Details fehlgeschlagen: {e}"))).ok();
            return;
        }
    };

    match details.os_type.as_str() {
        "linux-netboot" => {
            let kernel = details.kernel.expect("kein kernel im Manifest");
            let initrd = details.initrd.expect("kein initrd im Manifest");

            if let Err(e) = download_and_verify(&kernel, "/tmp/kernel", "Kernel wird geladen", &tx) {
                tx.send(ProgressMsg::Error(format!("Kernel-Download fehlgeschlagen: {e}"))).ok();
                return;
            }
            if let Err(e) = download_and_verify(&initrd, "/tmp/initrd", "Initrd wird geladen", &tx) {
                tx.send(ProgressMsg::Error(format!("Initrd-Download fehlgeschlagen: {e}"))).ok();
                return;
            }

            let cmdline = details.cmdline.unwrap_or_default();
            // TODO Stufe 3: hier direkt kexec statt nur anzuzeigen.
            tx.send(ProgressMsg::Done(format!(
                "Bereit für kexec (cmdline: {cmdline})"
            )))
            .ok();
        }
        "windows-wimboot" => {
            tx.send(ProgressMsg::Error("Windows/wimboot-Flow noch nicht implementiert (Stufe 3).".into())).ok();
        }
        "iso-full" => {
            let iso = details.iso.expect("kein iso im Manifest");
            if let Err(e) = download_and_verify(&iso, "/tmp/install.iso", "ISO wird geladen", &tx) {
                tx.send(ProgressMsg::Error(format!("ISO-Download fehlgeschlagen: {e}"))).ok();
                return;
            }
            tx.send(ProgressMsg::Done("ISO geladen — Weiterverarbeitung folgt in Stufe 3.".into())).ok();
        }
        other => {
            tx.send(ProgressMsg::Error(format!("Unbekannter OS-Typ: {other}"))).ok();
        }
    }
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let window = MainWindow::new()?;

    // OS-Liste initial laden (synchron, vor dem ersten Frame — reicht für
    // eine kurze API-Antwort; falls das mal langsam ist, kann das später
    // ebenfalls in den Hintergrund-Thread wandern).
    let initial_list = fetch_os_list().unwrap_or_default();
    let model: Vec<OsEntry> = initial_list
        .iter()
        .map(|e| OsEntry {
            id: e.id.clone().into(),
            name: e.name.clone().into(),
            version: e.version.clone().into(),
            os_type: e.os_type.clone().into(),
        })
        .collect();
    if model.is_empty() {
        window.set_status_line("Fehler beim Laden der OS-Liste vom Server.".into());
    }
    window.set_os_list(std::rc::Rc::new(slint::VecModel::from(model)).into());

    let os_list_rust: std::rc::Rc<std::cell::RefCell<Vec<OsSummary>>> =
        std::rc::Rc::new(std::cell::RefCell::new(initial_list));

    {
        let window_weak = window.as_weak();
        window.on_os_selected(move |idx| {
            if let Some(window) = window_weak.upgrade() {
                window.set_selected_index(idx);
            }
        });
    }

    {
        let window_weak = window.as_weak();
        let os_list_rust = os_list_rust.clone();
        window.on_confirm_selection(move || {
            let Some(window) = window_weak.upgrade() else { return };
            let idx = window.get_selected_index() as usize;
            let Some(chosen) = os_list_rust.borrow().get(idx).cloned() else { return };

            window.set_downloading(true);
            window.set_status_line(format!("Installiere: {}", chosen.name).into());

            let (tx, rx) = crossbeam_channel::unbounded::<ProgressMsg>();
            std::thread::spawn(move || run_install_flow(chosen.id, tx));

            // Channel im UI-Event-Loop pollen (einfacher Ansatz für Stufe 2;
            // für Stufe 3 ggf. auf einen async-Executor umstellen).
            let window_weak2 = window_weak.clone();
            let timer = slint::Timer::default();
            timer.start(
                slint::TimerMode::Repeated,
                std::time::Duration::from_millis(100),
                move || {
                    let Some(window) = window_weak2.upgrade() else { return };
                    while let Ok(msg) = rx.try_recv() {
                        match msg {
                            ProgressMsg::Status(s) => window.set_status_line(s.into()),
                            ProgressMsg::Progress { label, pct, speed, eta } => {
                                window.set_download_label(label.into());
                                window.set_download_progress(pct);
                                window.set_download_speed(speed.into());
                                window.set_download_eta(eta.into());
                            }
                            ProgressMsg::Done(s) => {
                                window.set_status_line(s.into());
                            }
                            ProgressMsg::Error(s) => {
                                window.set_status_line(format!("Fehler: {s}").into());
                                window.set_downloading(false);
                            }
                        }
                    }
                },
            );
        });
    }

    window.run()?;
    Ok(())
}
