fn main() {
    slint_build::compile("ui/main.slint").expect("Slint-UI konnte nicht kompiliert werden");
}
