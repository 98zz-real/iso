# boot-client — eigenes Remote-OS-Installer-System

Kein GRUB/iPXE-Theming — das hier ist die Grundlage für ein komplett
selbstgebautes minimales Linux, das direkt in diese App bootet.

## Ausbaustufen

**Stufe 1 (abgeschlossen):** Kernlogik — Manifest von `boot.chatlh.de` laden,
OS auswählen, Kernel/initrd (oder ISO) herunterladen mit Fortschrittsanzeige
+ SHA-256-Verifikation. War als reines Terminal-Programm getestet.

**Stufe 2 (aktueller Stand):** Eigene grafische Oberfläche mit
[Slint](https://slint.dev), `linuxkms`-Backend (rendert direkt auf
`/dev/dri`, kein X11/Wayland nötig — genau richtig für ein
Single-App-Bootsystem).

- `ui/theme.slint` — zentrale Farb-/Font-Tokens (eigenes Neon-Farbschema)
- `ui/hud_frame.slint` — der Rahmen: vier Ecken-Klammern + gepunktete
  Leisten oben/unten, eigenständig gestaltet (kein Nachbau des
  Referenzbilds, nur die Grundidee: Rahmen im HUD-Stil, Mitte komplett frei)
- `ui/main.slint` — der eigentliche Inhalt im Rahmen: OS-Auswahlliste +
  Download-Fortschrittsanzeige (Balken, %, Speed, ETA)
- `src/main.rs` — verdrahtet die UI mit der Download-Logik aus Stufe 1:
  Download läuft in einem Hintergrund-Thread, meldet Fortschritt über einen
  Channel, ein Timer im UI-Thread pollt den Channel und aktualisiert die
  Slint-Properties

### Bauen

**Wichtig:** braucht eine echte Linux-Umgebung mit `/dev/dri` (KMS-Zugriff).
Auf einem normalen Desktop unter X11/Wayland kann es zu Konflikten kommen —
am saubersten auf der Zielkonsole (tty, ohne laufenden Compositor) testen,
oder in einer VM mit durchgereichter/virtueller GPU.

```bash
cd boot-client
cargo build --release
sudo ./target/release/boot-client   # braucht Zugriff auf /dev/dri
```

Voraussetzung: Rust-Toolchain (`rustup`) und Internetzugang beim ersten
Build (crates.io für `slint`, `ureq`, etc.). Das ist in dieser Sandbox nicht
verfügbar — der Code wurde hier nur geschrieben, nicht kompiliert. Bitte
lokal/auf dem Zielsystem `cargo build` als ersten Test laufen lassen.

**Stufe 3 (als Nächstes):** `kexec` für Linux-Ziele (aktuell nur
Platzhalter-Meldung "Bereit für kexec"), wimboot-Flow für Windows,
ISO-Writer für den `iso-full`-Fallback.

**Stufe 4:** Alles in ein minimales Root-Filesystem packen (Buildroot),
`boot-client` als Init (PID 1) einbinden, per einfachem EFI-Stub/
`systemd-boot` auf dem Stick starten.

## Buildroot-Grundgerüst (Stufe 4, grober Fahrplan)

```bash
git clone https://github.com/buildroot/buildroot.git
cd buildroot
make menuconfig
```

Wichtige Optionen:
- Target Architecture: x86_64
- Kernel: eigene minimal-Config (KMS-Treiber für deine Ziel-GPU aktivieren!)
- Init system: keines der Standard-Inits — später ersetzt du `/sbin/init`
  durch die `boot-client`-Binary (per `BR2_ROOTFS_OVERLAY` oder
  Post-Build-Script)
- Networking: DHCP-Client (z. B. `udhcpc`) mit reinnehmen
- Filesystem: initramfs (cpio) als Output-Format

Das ist der Punkt, an dem sich Stufe 1–3 (die App) und Stufe 4 (das
Trägersystem drumherum) zusammenfügen.

## Nächster konkreter Schritt

`cargo build` lokal/auf dem Zielsystem laufen lassen, Layout/Farben im
Slint-Code nach Geschmack anpassen, danach Stufe 3 (kexec) angehen.
