# Remote-OS-Installer

Modularer, selbstgebauter Remote-OS-Installer: bootfähiger USB-Stick mit
eigenem Boot-System, das Betriebssysteme über das Netzwerk von einem
selbst gehosteten Server (`boot.chatlh.de`, via cloudflared-Tunnel) lädt.

## Struktur

```
remote-os-installer/
  install.sh              Ein-Kommando-Setup für den ISO-Server (diese Datei)
  iso-server/              Flask-API + Datei-Auslieferung (Kernel, initrd, ISOs)
    deploy/                systemd-Unit + nginx-Config, werden von install.sh benutzt
    manifests/os.json       Liste der verfügbaren Betriebssysteme
    data/                   Nutzdaten (nicht in Git — lokal befüllen)
  boot-client/             Eigener Boot-Client (Rust) — Stufe 1: Kernlogik,
                            spätere Stufen: eigene DRM/KMS-Oberfläche + kexec
```

## Server einrichten (ISO-Server + nginx + cloudflared)

```bash
git clone <dein-repo-url> remote-os-installer
cd remote-os-installer
```

Vor dem Ausführen: in `install.sh` ganz oben `CLOUDFLARE_TUNNEL_TOKEN`
eintragen (Cloudflare Zero Trust Dashboard -> Networks -> Tunnels -> dein
Tunnel -> Connector-Token).

```bash
sudo ./install.sh
```

Das Skript macht in einem Rutsch:
1. System-Pakete installieren (Python, nginx, curl, git)
2. Python-venv für den ISO-Server einrichten + Abhängigkeiten installieren
3. ISO-Server als systemd-Service (`iso-server`) einrichten und starten
4. nginx als Reverse-Proxy vor den Server schalten (inkl. Range-Request-Support
   fürs Pause/Resume beim Download)
5. cloudflared installieren und den Tunnel-Service registrieren

Nach dem Lauf: `systemctl status iso-server`, `curl http://localhost/api/v1/os`.

## Daten befüllen

Siehe `iso-server/README.md` — Kurzfassung:

```bash
# Dateien nach iso-server/data/<os-id>/... legen (Pfade passend zu manifests/os.json)
iso-server/venv/bin/python iso-server/hash_files.py
```

## Boot-Client

Siehe `boot-client/README.md` für den aktuellen Stand (Stufe 1: Terminal-
Programm, das Manifest lädt und Downloads verifiziert) und die geplanten
nächsten Ausbaustufen (eigene grafische Oberfläche, kexec, Buildroot-Image).
