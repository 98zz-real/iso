// boot-client — Stufe 1: Kernlogik (Manifest laden, Download + Verifikation)
//
// Läuft aktuell noch als simples Terminal-Programm. Das ist bewusst so:
// erst die Logik (Netzwerk, Hashes, kexec) zum Laufen bringen, danach als
// Stufe 2 die eigene DRM/KMS-Oberfläche drumherum bauen, die exakt so
// aussieht wie das Referenzbild (nur der Rahmen, Mitte frei gestaltet).
//
// Später als PID 1 / init im initramfs eingebunden.

use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{Read, Write};
use std::time::Instant;

const SERVER_BASE: &str = "https://boot.chatlh.de";

#[derive(Debug, Deserialize)]
struct OsListResponse {
    os: Vec<OsSummary>,
}

#[derive(Debug, Deserialize)]
struct OsSummary {
    id: String,
    name: String,
    version: String,
    #[serde(rename = "type")]
    os_type: String,
}

#[derive(Debug, Deserialize)]
struct FileRef {
    path: String,
    sha256: String,
    url: String,
}

#[derive(Debug, Deserialize)]
struct OsDetails {
    id: String,
    #[serde(rename = "type")]
    os_type: String,
    kernel: Option<FileRef>,
    initrd: Option<FileRef>,
    iso: Option<FileRef>,
    cmdline: Option<String>,
}

fn fetch_os_list() -> Result<Vec<OsSummary>, Box<dyn std::error::Error>> {
    let url = format!("{SERVER_BASE}/api/v1/os");
    let resp: OsListResponse = ureq::get(&url).call()?.into_json()?;
    Ok(resp.os)
}

fn fetch_os_details(id: &str) -> Result<OsDetails, Box<dyn std::error::Error>> {
    let url = format!("{SERVER_BASE}/api/v1/os/{id}");
    let details: OsDetails = ureq::get(&url).call()?.into_json()?;
    Ok(details)
}

/// Lädt eine Datei herunter, zeigt Fortschritt/Speed/ETA im Terminal (Stufe 1
/// — wird später durch die GUI-Progressbar ersetzt) und prüft danach den
/// SHA-256-Hash. Bricht mit Fehler ab, wenn der Hash nicht passt.
fn download_and_verify(file_ref: &FileRef, dest_path: &str) -> Result<(), Box<dyn std::error::Error>> {
    let url = if file_ref.url.starts_with("http") {
        file_ref.url.clone()
    } else {
        format!("{SERVER_BASE}{}", file_ref.url)
    };

    println!("-> Lade {url}");
    let resp = ureq::get(&url).call()?;
    let total_len: Option<u64> = resp
        .header("Content-Length")
        .and_then(|v| v.parse().ok());

    let mut reader = resp.into_reader();
    let mut out_file = File::create(dest_path)?;
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 1024 * 64];
    let mut downloaded: u64 = 0;
    let start = Instant::now();

    loop {
        let n = reader.read(&mut buf)?;
        if n == 0 {
            break;
        }
        out_file.write_all(&buf[..n])?;
        hasher.update(&buf[..n]);
        downloaded += n as u64;

        let elapsed = start.elapsed().as_secs_f64().max(0.001);
        let speed_mb_s = (downloaded as f64 / 1_000_000.0) / elapsed;
        match total_len {
            Some(total) => {
                let pct = (downloaded as f64 / total as f64) * 100.0;
                let remaining = total.saturating_sub(downloaded);
                let eta_s = if speed_mb_s > 0.0 {
                    (remaining as f64 / 1_000_000.0) / speed_mb_s
                } else {
                    0.0
                };
                print!(
                    "\r   {:.1}%  {:.2} MB/s  ETA {:.0}s   ",
                    pct, speed_mb_s, eta_s
                );
            }
            None => {
                print!("\r   {} MB geladen  {:.2} MB/s   ", downloaded / 1_000_000, speed_mb_s);
            }
        }
        std::io::stdout().flush().ok();
    }
    println!();

    let computed_hash = format!("{:x}", hasher.finalize());
    if computed_hash != file_ref.sha256 {
        return Err(format!(
            "Hash-Mismatch bei {}: erwartet {}, erhalten {}",
            file_ref.path, file_ref.sha256, computed_hash
        )
        .into());
    }
    println!("   Hash verifiziert ({computed_hash})");
    Ok(())
}

fn main() {
    println!("=== Remote-OS-Installer — boot-client (Stufe 1: Terminal) ===\n");

    let list = match fetch_os_list() {
        Ok(l) => l,
        Err(e) => {
            eprintln!("Konnte OS-Liste nicht laden: {e}");
            std::process::exit(1);
        }
    };

    println!("Verfügbare Systeme:");
    for (i, os) in list.iter().enumerate() {
        println!("  [{i}] {} ({}) — {}", os.name, os.version, os.os_type);
    }

    // TODO Stufe 2: statt stdin-Eingabe -> Auswahl über die eigene
    // GUI (Tastatur/Encoder-Input), Rendering via DRM/KMS.
    print!("\nAuswahl (Index): ");
    std::io::stdout().flush().ok();
    let mut input = String::new();
    std::io::stdin().read_line(&mut input).ok();
    let idx: usize = input.trim().parse().unwrap_or(0);

    let chosen = &list[idx];
    println!("\nGewählt: {}\n", chosen.name);

    let details = fetch_os_details(&chosen.id).expect("Details konnten nicht geladen werden");

    match details.os_type.as_str() {
        "linux-netboot" => {
            let kernel = details.kernel.expect("kein kernel im Manifest");
            let initrd = details.initrd.expect("kein initrd im Manifest");
            download_and_verify(&kernel, "/tmp/kernel").expect("Kernel-Download fehlgeschlagen");
            download_and_verify(&initrd, "/tmp/initrd").expect("Initrd-Download fehlgeschlagen");

            let cmdline = details.cmdline.unwrap_or_default();
            println!("\nBereit für kexec:");
            println!("  kexec -l /tmp/kernel --initrd=/tmp/initrd --append=\"{cmdline}\"");
            println!("  kexec -e");
            // TODO: kexec-Aufruf direkt aus Rust via `kexec` crate oder
            // Shell-out zu /sbin/kexec, sobald Stufe 1 stabil läuft.
        }
        "windows-wimboot" => {
            println!("Windows-Installation: wimboot-Flow noch nicht implementiert (TODO Stufe 3).");
        }
        "iso-full" => {
            let iso = details.iso.expect("kein iso im Manifest");
            download_and_verify(&iso, "/tmp/install.iso").expect("ISO-Download fehlgeschlagen");
            println!("ISO geladen — Weiterverarbeitung (auf SSD schreiben o.ä.) folgt in Stufe 3.");
        }
        other => {
            eprintln!("Unbekannter OS-Typ: {other}");
        }
    }
}
