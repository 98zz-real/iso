# boot-client — eigenes Remote-OS-Installer-System

Kein GRUB/iPXE-Theming — das hier ist die Grundlage für ein komplett
selbstgebautes minimales Linux, das direkt in diese App bootet.

## Ausbaustufen

**Stufe 1 (aktueller Stand):** `src/main.rs` — Kernlogik als Terminal-Programm:
Manifest von `boot.chatlh.de` laden, OS auswählen, Kernel/initrd (oder ISO)
herunterladen mit Fortschrittsanzeige + SHA-256-Verifikation. Läuft aktuell
noch ganz normal unter jedem Linux zum Testen der Netzwerk-Logik.

**Stufe 2 (als Nächstes):** Terminal-UI durch eigene DRM/KMS-Oberfläche
ersetzen. Empfehlung: [`smithay-client-toolkit`] ist für Wayland-Clients,
das brauchst du nicht — für eine einzelne fullscreen App direkt auf dem
Framebuffer eignet sich besser:
- Crate [`drm`] + [`gbm`] für den Low-Level-Zugriff, oder
- höher angesetzt: [`slint`] mit dem `linuxkms`-Backend (macht DRM/Input
  intern, du entwirfst nur noch das UI in `.slint`-Dateien — deutlich
  schneller für ein individuelles Design als raw DRM).

Für den Rahmen aus deinem Referenzbild: als SVG nachbauen (Ecken, Neon-Linien,
Punktreihen oben/unten), in Slint/Skia einbinden, Mitte komplett frei mit
eigenen Elementen (Liste, Fortschrittsbalken, Buttons) füllen.

**Stufe 3:** `kexec` für Linux-Ziele, wimboot-Flow für Windows, ISO-Writer
für den `iso-full`-Fallback.

**Stufe 4:** Alles in ein minimales Root-Filesystem packen (Buildroot),
`boot-client` als Init (PID 1) einbinden, per `systemd-boot`/einfachem
EFI-Stub auf dem Stick starten.

## Stufe 1 lokal testen

Setzt Rust + Internetzugang voraus (crates.io):

```bash
cd boot-client
cargo run
```

Erwartet, dass dein ISO-Server unter `https://boot.chatlh.de` erreichbar ist
und mindestens einen OS-Eintrag mit vorhandenen Dateien + korrekten Hashes hat
(siehe `iso-server/README.md`, `hash_files.py`).

## Buildroot-Grundgerüst (Stufe 4, grober Fahrplan)

```bash
git clone https://github.com/buildroot/buildroot.git
cd buildroot
make menuconfig
```

Wichtige Optionen:
- Target Architecture: x86_64
- Kernel: eigene minimal-Config (KMS-Treiber für deine Ziel-GPU aktivieren!)
- Init system: keines der Standard-Inits — später ersetzt du `/sbin/init`
  durch die `boot-client`-Binary (per `BR2_ROOTFS_OVERLAY` oder
  Post-Build-Script)
- Networking: DHCP-Client (z. B. `udhcpc`) mit reinnehmen
- Filesystem: initramfs (cpio) als Output-Format

Das ist der Punkt, an dem sich Stufe 1–3 (die App) und Stufe 4 (das
Trägersystem drumherum) zusammenfügen.

## Nächster konkreter Schritt

Ich würde vorschlagen: Stufe 1 zuerst gegen deinen echten ISO-Server laufen
lassen (Debian-netboot-Dateien reinlegen, Hashes berechnen, `cargo run`
testen) — dann steht die Netzwerklogik, bevor Grafik und Buildroot
dazukommen.
