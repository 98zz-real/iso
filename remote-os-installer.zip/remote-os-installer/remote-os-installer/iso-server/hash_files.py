"""
Berechnet SHA-256 für alle Dateien im data/-Verzeichnis, die im Manifest
referenziert werden, und aktualisiert manifests/os.json direkt.

Aufruf:
    python hash_files.py
"""

import hashlib
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MANIFEST_PATH = BASE_DIR / "manifests" / "os.json"
DATA_DIR = BASE_DIR / "data"


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def update_entry(file_obj):
    p = DATA_DIR / file_obj["path"]
    if not p.exists():
        print(f"  [fehlt] {file_obj['path']}")
        return
    digest = sha256_of(p)
    file_obj["sha256"] = digest
    print(f"  [ok]    {file_obj['path']} -> {digest}")


def main():
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    for entry in manifest["os"]:
        print(f"{entry['id']}:")
        for key in ("kernel", "initrd", "iso"):
            if key in entry:
                update_entry(entry[key])
        if "files" in entry:
            for key in entry["files"]:
                update_entry(entry["files"][key])

    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        f.write("\n")

    print("\nManifest aktualisiert.")


if __name__ == "__main__":
    main()
