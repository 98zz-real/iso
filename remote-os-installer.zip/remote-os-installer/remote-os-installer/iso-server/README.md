# ISO-Server — boot.chatlh.de

Liefert die API + Dateien für den Remote-OS-Installer-Stick.

## Struktur

```
iso-server/
  app.py               Flask-App (API + Datei-Auslieferung)
  hash_files.py         Berechnet SHA-256 für alle Dateien im Manifest
  manifests/os.json     Liste der verfügbaren Systeme
  data/                 Die eigentlichen Dateien (Kernel, initrd, ISOs, WIMs)
```

## Einrichtung

```bash
cd iso-server
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Dateien einpflegen

1. Kernel/initrd bzw. ISO/WIM-Dateien nach `data/<os-id>/...` legen —
   die Pfade müssen exakt zu denen in `manifests/os.json` passen.
2. Hashes berechnen:
   ```bash
   python hash_files.py
   ```
   Das trägt die echten SHA-256-Werte direkt ins Manifest ein
   (ersetzt die Platzhalter `REPLACE_ME`).
3. Prüfen, ob alles vollständig ist:
   ```bash
   curl http://localhost:8080/api/v1/verify/debian-12
   ```

## Neues OS hinzufügen

Einfach einen neuen Eintrag in `manifests/os.json` ergänzen (Typ `linux-netboot`
für Kernel+initrd-Direktboot, `windows-wimboot` für Windows via wimboot,
`iso-full` als Fallback für alles, was sich nicht netboot-fähig zerlegen lässt),
Dateien nach `data/` legen, `hash_files.py` laufen lassen.

## Lokal testen

```bash
python app.py
# -> http://localhost:8080/api/v1/os
```

## Produktiv-Betrieb (gunicorn + nginx + cloudflared)

**gunicorn** (Prozess-Manager, z. B. via systemd-Service):
```bash
gunicorn -w 4 -b 127.0.0.1:8080 app:app
```

**nginx** (Reverse Proxy vor gunicorn, wichtig für Range-Requests bei großen
ISOs und um X-Sendfile/sendfile-Optimierung zu nutzen):
```nginx
server {
    listen 80;
    server_name boot.chatlh.de;

    client_max_body_size 0;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_http_version 1.1;
        # Range-Requests durchreichen, wichtig fürs Pause/Resume im Client
        proxy_set_header Range $http_range;
        proxy_set_header If-Range $http_if_range;
    }
}
```

**cloudflared** (Tunnel-Config, bereits vorhanden bei dir — nur der Vollständigkeit
halber, damit der Eintrag zu diesem Server passt):
```yaml
ingress:
  - hostname: boot.chatlh.de
    service: http://localhost:80
  - service: http_status:404
```

## Nächste Schritte

- [ ] Echte Kernel/initrd für Debian/Ubuntu besorgen (offizielle netboot-Verzeichnisse
      der Distros, z. B. `debian.org/.../netboot/`)
- [ ] Windows: `bootmgr`, `BCD`, `boot.wim`, `install.wim` aus einem offiziellen
      Windows-ISO extrahieren (siehe wimboot-Doku)
- [ ] Optional: Auth-Token für die API, falls der Server nicht komplett offen sein soll
- [ ] Optional: Rate-Limiting in nginx gegen Missbrauch
