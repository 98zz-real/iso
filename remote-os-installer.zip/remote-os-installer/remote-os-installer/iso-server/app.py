"""
ISO/Boot-Server für den Remote-OS-Installer.

Liefert:
  GET /api/v1/os              -> Liste aller verfügbaren Systeme (Kurzinfo)
  GET /api/v1/os/<id>         -> Details inkl. Download-Pfade + SHA-256
  GET /files/<path:relpath>   -> liefert die eigentliche Datei, unterstützt
                                  HTTP Range-Requests (Pause/Resume im Client)

Dateien liegen unter DATA_DIR/<path aus manifest>.
Läuft hinter cloudflared -> boot.chatlh.de (Cloudflare übernimmt TLS,
hier lokal reicht HTTP hinter dem Tunnel).

Start (Entwicklung):
    pip install flask
    python app.py

Produktiv (empfohlen): hinter gunicorn + nginx, siehe README.md.
"""

import hashlib
import json
import os
from pathlib import Path

from flask import Flask, jsonify, abort, send_from_directory, request

BASE_DIR = Path(__file__).resolve().parent
MANIFEST_PATH = BASE_DIR / "manifests" / "os.json"
DATA_DIR = BASE_DIR / "data"

app = Flask(__name__)


def load_manifest():
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def short_info(entry: dict) -> dict:
    """Reduzierte Info für die Übersichtsliste (keine internen Pfade)."""
    return {
        "id": entry["id"],
        "name": entry["name"],
        "version": entry["version"],
        "type": entry["type"],
        "arch": entry.get("arch", "x86_64"),
    }


@app.get("/api/v1/os")
def list_os():
    manifest = load_manifest()
    return jsonify({"os": [short_info(e) for e in manifest["os"]]})


@app.get("/api/v1/os/<os_id>")
def os_details(os_id):
    manifest = load_manifest()
    entry = next((e for e in manifest["os"] if e["id"] == os_id), None)
    if entry is None:
        abort(404, description="Unbekannte OS-ID")

    # Pfade zu vollen Download-URLs (relativ) umbauen, Original-Manifest
    # unangetastet lassen.
    result = json.loads(json.dumps(entry))  # deep copy

    def to_url(file_obj):
        file_obj["url"] = f"/files/{file_obj['path']}"
        return file_obj

    if "kernel" in result:
        to_url(result["kernel"])
    if "initrd" in result:
        to_url(result["initrd"])
    if "iso" in result:
        to_url(result["iso"])
    if "files" in result:
        for key in result["files"]:
            to_url(result["files"][key])

    return jsonify(result)


@app.get("/files/<path:relpath>")
def serve_file(relpath):
    # send_from_directory prüft bereits gegen Path-Traversal,
    # unterstützt Range-Requests automatisch (conditional=True).
    full_path = (DATA_DIR / relpath).resolve()
    if not str(full_path).startswith(str(DATA_DIR.resolve())):
        abort(403)
    if not full_path.exists():
        abort(404, description="Datei liegt noch nicht auf dem Server")
    return send_from_directory(DATA_DIR, relpath, conditional=True)


@app.get("/api/v1/verify/<os_id>")
def verify_files_present(os_id):
    """Praktischer Debug-Endpunkt: prüft, ob alle im Manifest referenzierten
    Dateien tatsächlich vorhanden sind und ob die hinterlegten Hashes bereits
    gesetzt wurden (nicht mehr REPLACE_ME)."""
    manifest = load_manifest()
    entry = next((e for e in manifest["os"] if e["id"] == os_id), None)
    if entry is None:
        abort(404)

    def check(file_obj):
        p = DATA_DIR / file_obj["path"]
        return {
            "path": file_obj["path"],
            "exists": p.exists(),
            "hash_set": file_obj.get("sha256") != "REPLACE_ME",
        }

    checks = []
    for key in ("kernel", "initrd", "iso"):
        if key in entry:
            checks.append(check(entry[key]))
    if "files" in entry:
        for key in entry["files"]:
            checks.append(check(entry["files"][key]))

    return jsonify({"os_id": os_id, "files": checks})


if __name__ == "__main__":
    DATA_DIR.mkdir(exist_ok=True)
    app.run(host="0.0.0.0", port=8080, debug=True)
