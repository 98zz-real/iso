#!/usr/bin/env bash
#
# install.sh — Remote-OS-Installer: ISO-Server + nginx + cloudflared
#
# Einmalig ausführen auf dem Server, der die ISOs/Kernel/initrds hostet:
#
#   git clone <dein-repo-url> remote-os-installer
#   cd remote-os-installer
#   sudo ./install.sh
#
# Vor dem Ausführen unbedingt CLOUDFLARE_TUNNEL_TOKEN unten eintragen
# (siehe Cloudflare Zero Trust Dashboard -> Networks -> Tunnels ->
# dein Tunnel -> "Install and run a connector" -> Token aus dem
# "cloudflared service install <TOKEN>"-Befehl).

set -euo pipefail

# ---------------------------------------------------------------------------
# Konfiguration — hier anpassen
# ---------------------------------------------------------------------------
CLOUDFLARE_TUNNEL_TOKEN="PASTE_YOUR_TOKEN_HERE"

# ---------------------------------------------------------------------------
# Ab hier normalerweise nichts ändern
# ---------------------------------------------------------------------------

if [[ $EUID -ne 0 ]]; then
    echo "Bitte mit sudo/als root ausführen: sudo ./install.sh"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ISO_SERVER_DIR="$SCRIPT_DIR/iso-server"
RUN_USER="${SUDO_USER:-$USER}"

echo "==> Remote-OS-Installer wird eingerichtet"
echo "    Repo-Verzeichnis : $SCRIPT_DIR"
echo "    Service-User     : $RUN_USER"
echo

# ---------------------------------------------------------------------------
# 1) System-Pakete
# ---------------------------------------------------------------------------
echo "==> [1/5] System-Pakete installieren"
apt-get update
apt-get install -y python3 python3-venv python3-pip nginx curl gnupg git

# ---------------------------------------------------------------------------
# 2) ISO-Server: venv + Abhängigkeiten
# ---------------------------------------------------------------------------
echo "==> [2/5] ISO-Server: Python-venv einrichten"
sudo -u "$RUN_USER" python3 -m venv "$ISO_SERVER_DIR/venv"
sudo -u "$RUN_USER" "$ISO_SERVER_DIR/venv/bin/pip" install --upgrade pip
sudo -u "$RUN_USER" "$ISO_SERVER_DIR/venv/bin/pip" install -r "$ISO_SERVER_DIR/requirements.txt"

mkdir -p "$ISO_SERVER_DIR/data"
chown -R "$RUN_USER":"$RUN_USER" "$ISO_SERVER_DIR/data"

# ---------------------------------------------------------------------------
# 3) systemd-Service für den ISO-Server
# ---------------------------------------------------------------------------
echo "==> [3/5] systemd-Service einrichten"
sed \
    -e "s#__INSTALL_DIR__#$SCRIPT_DIR#g" \
    -e "s#__RUN_USER__#$RUN_USER#g" \
    "$ISO_SERVER_DIR/deploy/iso-server.service" > /etc/systemd/system/iso-server.service

systemctl daemon-reload
systemctl enable iso-server
systemctl restart iso-server

# ---------------------------------------------------------------------------
# 4) nginx-Reverse-Proxy
# ---------------------------------------------------------------------------
echo "==> [4/5] nginx einrichten"
cp "$ISO_SERVER_DIR/deploy/nginx.conf" /etc/nginx/sites-available/boot.chatlh.de
ln -sf /etc/nginx/sites-available/boot.chatlh.de /etc/nginx/sites-enabled/boot.chatlh.de
nginx -t
systemctl reload nginx

# ---------------------------------------------------------------------------
# 5) cloudflared installieren + Tunnel registrieren
# ---------------------------------------------------------------------------
echo "==> [5/5] cloudflared installieren"

# Cloudflare-GPG-Key hinzufügen
mkdir -p --mode=0755 /usr/share/keyrings
curl -fsSL https://pkg.cloudflare.com/cloudflare-public-v2.gpg | tee /usr/share/keyrings/cloudflare-public-v2.gpg >/dev/null

# Repo hinzufügen
echo 'deb [signed-by=/usr/share/keyrings/cloudflare-public-v2.gpg] https://pkg.cloudflare.com/cloudflared any main' | tee /etc/apt/sources.list.d/cloudflared.list

# cloudflared installieren
apt-get update
apt-get install -y cloudflared

if [[ "$CLOUDFLARE_TUNNEL_TOKEN" == "PASTE_YOUR_TOKEN_HERE" ]]; then
    echo
    echo "!! CLOUDFLARE_TUNNEL_TOKEN wurde nicht angepasst — Tunnel-Service wird NICHT installiert."
    echo "   Trag deinen Token oben in install.sh ein und führ danach manuell aus:"
    echo "     sudo cloudflared service install <DEIN_TOKEN>"
else
    cloudflared service install "eyJhIjoiNDBjMDMyZjk4YmFjZTA0NzJhZjA3NDIyMGEzNjdjNzUiLCJ0IjoiYjMzYmI4MmMtNjMwZS00MzFjLWE3YmMtY2VkNGMyOTU5YjBmIiwicyI6IlpHWTBPR1pqTW1VdE5qTTBNaTAwWlRFeUxUZ3haV1V0TjJFMk5HRXlNVFEzT1RBMyJ9"
fi

echo
echo "==> Fertig."
echo "    ISO-Server läuft lokal auf 127.0.0.1:8080 (via nginx auf Port 80)."
echo "    Status prüfen:      systemctl status iso-server"
echo "    Logs ansehen:       journalctl -u iso-server -f"
echo "    API testen:         curl http://localhost/api/v1/os"
echo
echo "    Nächste Schritte:"
echo "    - Kernel/initrd/ISOs nach $ISO_SERVER_DIR/data/<os-id>/ legen"
echo "    - Hashes berechnen: $ISO_SERVER_DIR/venv/bin/python $ISO_SERVER_DIR/hash_files.py"
echo "    - Falls Tunnel noch nicht lief: Token in install.sh eintragen und erneut ausführen"
