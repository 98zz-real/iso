include $(sort $(wildcard $(BR2_EXTERNAL_BOOTCLIENT_PATH)/package/*/*.mk))
