#!/bin/sh
# Wird von Buildroot nach dem fertigen Image-Build ausgeführt.
# Baut daraus ein flashbares USB-Stick-Image via genimage.

set -e
BOARD_DIR="$(dirname "$0")"
GENIMAGE_CFG="${BOARD_DIR}/genimage.cfg"
GENIMAGE_TMP="${BUILD_DIR}/genimage.tmp"

# EFI-Stub-Ansatz: Wenn im Kernel CONFIG_EFI_STUB=y UND
# CONFIG_INITRAMFS_SOURCE auf Buildroots rootfs.cpio zeigt (Standard bei
# initramfs-Output), ist bzImage selbst ein direkt EFI-bootfähiges Programm
# mit eingebettetem Rootfs — kein separater Bootloader, kein separates
# initrd auf dem Stick nötig.
mkdir -p "${BINARIES_DIR}/EFI/BOOT"

if [ ! -f "${BINARIES_DIR}/bzImage" ]; then
	echo "post-image.sh: bzImage nicht in ${BINARIES_DIR} gefunden." >&2
	echo "  -> Prüfe in menuconfig: CONFIG_EFI_STUB=y und" >&2
	echo "     CONFIG_INITRAMFS_SOURCE=\"\$(BINARIES_DIR)/rootfs.cpio\"" >&2
	exit 1
fi

cp "${BINARIES_DIR}/bzImage" "${BINARIES_DIR}/EFI/BOOT/BOOTX64.EFI"

rm -rf "${GENIMAGE_TMP}"

genimage \
	--rootpath "${TARGET_DIR}" \
	--tmppath "${GENIMAGE_TMP}" \
	--inputpath "${BINARIES_DIR}" \
	--outputpath "${BINARIES_DIR}" \
	--config "${GENIMAGE_CFG}"

echo ">>> Fertig: ${BINARIES_DIR}/bootclient.img"
echo ">>> Auf Stick schreiben mit z.B.:"
echo ">>>   sudo dd if=${BINARIES_DIR}/bootclient.img of=/dev/sdX bs=4M status=progress conv=fsync"
