#!/bin/sh
# Wird von Buildroot nach dem Rootfs-Aufbau ausgeführt.
# $1 = Pfad zum Ziel-Rootfs (TARGET_DIR)

set -e
TARGET_DIR="$1"

# boot-client übernimmt PID 1 direkt statt eines normalen Init-Systems.
ln -sf /usr/bin/boot-client "${TARGET_DIR}/sbin/init"
