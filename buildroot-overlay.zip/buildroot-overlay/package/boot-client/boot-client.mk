################################################################################
#
# boot-client
#
################################################################################

# Zeigt auf das lokale Projektverzeichnis (roi/boot-client aus dem ZIP).
# Passe den Pfad an, falls du das Overlay woanders hinlegst.
BOOT_CLIENT_SITE = $(BR2_EXTERNAL_BOOTCLIENT_PATH)/../roi/boot-client
BOOT_CLIENT_SITE_METHOD = local
BOOT_CLIENT_LICENSE = Proprietary

$(eval $(cargo-package))
